import pandas as pd
import math
from datetime import datetime
import bisect
import numpy as np
import pdb
# 读取 Excel 文件
df = pd.read_excel('/local/code/work/out.xlsx', sheet_name='Sheet1')  # 指定工作表名称
df2 = pd.read_excel('/local/code/work/out2.xlsx', sheet_name='Sheet1')  # 指定工作表名称

valid_time = datetime.strptime("2017-11-20 10:00:00.000", '%Y-%m-%d %H:%M:%S.%f')

flow_list = []
in_t_list = []
out_t_list = []
collect_time_list = []
outdoor_t_list = []
indoor_t_list = []
inputs = []

outdoor_time_t_dict = {}
for index, row in df2.iterrows():
    row_data_dict = row.to_dict()
    time = row_data_dict['时间'].to_pydatetime()
    outdoor_t = row_data_dict['温度']
    outdoor_time_t_dict[time] = outdoor_t

for index, row in df.iterrows():
    row_data_dict = row.to_dict()
    flow = row_data_dict['流速']
    in_t = row_data_dict['进水温度']
    out_t = row_data_dict['出水温度']
    indoor_t = row_data_dict['室内温度']
    time = row_data_dict['数据采集时间']
    format_time = datetime.strptime(time, '%Y-%m-%d %H:%M:%S.%f')
    format_time_str = format_time.strftime("%Y/%m/%d %H:%M")
    table2_format_time = datetime.strptime(format_time_str, "%Y/%m/%d %H:%M")
    if format_time < valid_time:
        continue
    else:
        if table2_format_time not in outdoor_time_t_dict.keys():
            continue
        else:
            flow_list.append(flow)
            in_t_list.append(in_t)
            out_t_list.append(out_t)
            collect_time_list.append(table2_format_time)
            indoor_t_list.append(indoor_t)
            inputs.append([flow, in_t, out_t, outdoor_time_t_dict[table2_format_time]])


# collect_time_list2 = []




# for i in range(len(collect_time_list2)):
#     assert collect_time_list[i] == collect_time_list2[i]

# inputs = [flow_list, in_t_list, out_t_list, outdoor_t_list]
# pdb.set_trace()
inputs_np = np.array(inputs, np.float32)
output_np = np.array(indoor_t_list, np.float32)
np.save('inputs.npy', inputs_np)
np.save('outputs.npy', output_np)
pdb.set_trace()







