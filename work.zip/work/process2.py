import pandas as pd
import math
from datetime import datetime
import bisect
import pdb
# 读取 Excel 文件
df = pd.read_excel('/local/code/work/out.xlsx', sheet_name='Sheet1')  # 指定工作表名称
df2 = pd.read_excel('/local/code/work/excel2.xlsx', sheet_name='Sheet1')  # 指定工作表名称

# 打印数据
# print(df)

# 遍历每行数据

valid = []
unvalid = []
data_dict = {}
table1_time_list = []
for index, row in df.iterrows():
    # print(f"第 {index} 行数据: {row.to_dict()}")
    row_data_dict = row.to_dict()
    if row_data_dict['building_name'] == "03#楼" and row_data_dict['单元名'] == "1单元" and \
        row_data_dict['单户号码'] == 101:
        format_collect_time = datetime.strptime(row_data_dict['数据采集时间'], '%Y-%m-%d %H:%M:%S.%f')
        format_collect_time_str = format_collect_time.strftime("%Y/%m/%d %H:%M")
        format_collect_time = datetime.strptime(format_collect_time_str, "%Y/%m/%d %H:%M")
        table1_time_list.append(format_collect_time)
    else:
        break


table2_time_list = []
tempeature_list = []
for index, row in df2.iterrows():
    # print(f"第 {index} 行数据: {row.to_dict()}")
    row_data_dict = row.to_dict()
    # pdb.set_trace() 
    format_collect_time = row_data_dict['时间'].to_pydatetime()
    # datetime.strptime(row_data_dict['时间'], '%Y/%m/%d %H:%M')
    table2_time_list.append(format_collect_time)
    tempeature_list.append(row_data_dict['温度'])

table2_begin_time = table2_time_list[0]

re_time_list = []
for time in table1_time_list:
    if time < table2_begin_time:
        continue
    else:
        re_time_list.append(time)

re_time_temperature_dict = dict()
re_time_temperature_dict['时间'] = []
re_time_temperature_dict['温度'] = []
for time in re_time_list:
    pos = bisect.bisect_left(table2_time_list, time)
    if pos == 0:  # 插入点在开头
        closest_time = table2_time_list[0]
        tempeature = tempeature_list[0]

    elif pos == len(table2_time_list):  # 插入点在末尾
        closest_time = table2_time_list[-1]
        tempeature = tempeature_list[-1]

    else:  # 比较插入点前后的元素
        before = table2_time_list[pos - 1]
        after = table2_time_list[pos]
        time_difference = time - before
        time_difference2 = after - time
        time_difference3 = after - before
        # 将差值转换为分钟
        difference_in_minutes = time_difference.total_seconds() / 60
        difference2_in_minutes = time_difference2.total_seconds() / 60
        difference3_in_minutes = time_difference3.total_seconds() / 60
        tempeature = (difference2_in_minutes / difference3_in_minutes) * tempeature_list[pos - 1] + \
            (difference_in_minutes / difference3_in_minutes) * tempeature_list[pos]
    
    re_time_temperature_dict['时间'].append(time)
    re_time_temperature_dict['温度'].append(tempeature)


df = pd.DataFrame(re_time_temperature_dict)

# 写入 Excel 文件
df.to_excel("out2.xlsx", index=False)     

# pdb.set_trace()
    