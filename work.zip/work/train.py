import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
np.random.seed(42)
import pdb

min_vals = None
max_vals = None

def Normalize(data):
    global min_vals, max_vals
    min_vals = np.min(data, axis=0)
    max_vals = np.max(data, axis=0)
    # 使用 Min-Max 公式归一化
    normalized_data = (data - min_vals) / (max_vals - min_vals)
    # pdb.set_trace()
    return normalized_data, min_vals, max_vals

def get_train_and_test(data):
    
    # 随机抽取 80% 的索引
    num_samples = data.shape[0]
    indices = np.arange(num_samples)
    np.random.shuffle(indices)  # 打乱索引
    train_size = int(num_samples * 0.8)  # 80% 的样本数量

    # 获取训练数据和剩余数据
    train_indices = indices[:train_size]
    test_indices = indices[train_size:]  # 剩余 20% 的索引（可选）

    data_train = data[train_indices]
    data_test = data[test_indices]  # 剩余数据
    return data_train, data_test


inputs_np = np.load('/local/code/work/inputs.npy',allow_pickle=True)
output_np = np.load('/local/code/work/outputs.npy',allow_pickle=True)

inputs_np_norm, inputs_min_vals, inputs_max_vals = Normalize(inputs_np)
output_np_norm, ouputs_min_vals, ouputs_max_vals = Normalize(output_np)
pdb.set_trace()
# 定义训练数据
N = 1000  # 数据样本数
input_size = 4
output_size = 1
hidden_size = 128
batch_size = 32
learning_rate = 0.0001
num_epochs = 30

# 随机生成数据
# X = torch.randn(N, 4)  # N, 4
# y = torch.randn(N)      # N
X = torch.from_numpy(inputs_np_norm).float()
y = torch.from_numpy(output_np_norm).float()
y = y.reshape(y.shape[0], 1)

Xy = torch.cat((X, y), -1)

Xy_train, Xy_test = get_train_and_test(Xy)
# pdb.set_trace()
X_train = Xy_train[..., :4]
y_train = Xy_train[..., 4:]

# 将数据加载到 DataLoader 中
train_dataset = TensorDataset(X_train, y_train)
train_loader = DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True)

# 定义 MLP 模型
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(4, hidden_size)   # 输入层到隐藏层
        self.fc2 = nn.Linear(hidden_size, hidden_size)  # 隐藏层到隐藏层
        self.fc3 = nn.Linear(hidden_size, 1)    # 最后一层输出层

    def forward(self, x):
        x = torch.relu(self.fc1(x))           # 激活函数 ReLU
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x


def test(model, best_acc, Xy_test):
    X_test = Xy_test[..., :4]
    y_test = Xy_test[..., 4:]

    y_pred = model(X_test)

    acc = torch.abs(y_pred.flatten() - y_test.flatten()).mean()
    if acc < best_acc:
        print('acc: ', acc)
        torch.save(model.state_dict(), 'mlp_model_acc{}.pth'.format(acc))
        best_acc = acc


# 实例化模型、损失函数和优化器
model = MLP()
criterion = nn.MSELoss()  # 损失函数为均方误差
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

# 训练模型
best_acc = 100000000
for epoch in range(num_epochs):
    for batch_idx, (inputs, targets) in enumerate(train_loader):
        # 前向传播
        outputs = model(inputs)
        outputs = outputs.flatten()
        targets = targets.flatten()
        # pdb.set_trace()
        loss = criterion(outputs, targets)
        if batch_idx % 50 == 0:
            print(f'iter [{batch_idx + 1}], Loss: {loss.item()}')

        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    test(model, best_acc, Xy_test)
    print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item()}')

# 保存模型
# torch.save(model.state_dict(), 'mlp_model.pth')
