import pandas as pd
import math
from datetime import datetime
import bisect
import pdb
# 读取 Excel 文件
df = pd.read_excel('/local/code/work/excel1.xlsx', sheet_name='Sheet1')  # 指定工作表名称

# 打印数据
# print(df)

# 遍历每行数据

valid = []
unvalid = []
data_dict = {}
for index, row in df.iterrows():
    # pdb.set_trace()
    # print(f"第 {index} 行数据: {row.to_dict()}")
    row_data_dict = row.to_dict()
    # if math.isnan(row.to_dict()['ROOM_SET_TEMPERATURE']) or row.to_dict()['ROOM_SET_TEMPERATURE'] == 0.0:
    #     unvalid.append(row.to_dict())
    # else:
    #     valid.append(row.to_dict())
    
    home = row_data_dict['单元名'] + '_' + str(row_data_dict['单户号码'])
    if data_dict.get(home) is None:
        data_dict[home] = dict()
        data_dict[home]['单元名'] = int(row_data_dict['单元名'].replace('单元', ''))
        data_dict[home]['number'] = row_data_dict['单户号码'] %  10  #
        data_dict[home]['layer'] = row_data_dict['单户号码'] // 100
        data_dict[home]['data'] = []
    collect_time = row_data_dict['数据采集时间']
    new_row_data_dict  = row_data_dict.copy()
    format_time = datetime.strptime(collect_time, '%Y-%m-%d %H:%M:%S.%f')
    new_row_data_dict['time'] = format_time
    data_dict[home]['data'].append(new_row_data_dict)


def find_t(i, data, home, data_dict):
    print(home)
    all_apart = [1, 2, 3]
    # all_home
    apart = data_dict[home]['单元名']
    home_layer = data_dict[home]['layer']
    home_number = data_dict[home]['number']
    home_data_list = data_dict[home]['data']
    unvalid = 0

    for j in range(i - 1, -1, -1):
        if unvalid > 5:
                break
        if math.isnan(home_data_list[j]['ROOM_SET_TEMPERATURE']) == False and\
             home_data_list[j]['室内温度'] != 0.0:
             ROOM_SET_TEMPERATURE = home_data_list[j]['ROOM_SET_TEMPERATURE']
             room_t = home_data_list[j]['室内温度']
             break
            #  return home_data_list[j]['ROOM_SET_TEMPERATURE'], home_data_list[j]['室内温度']
        else:
            unvalid += 1
             
    
    for j in range(i + 1, len(home_data_list)):
        if unvalid > 5:
                break
        if math.isnan(home_data_list[j]['ROOM_SET_TEMPERATURE']) == False and\
             home_data_list[j]['室内温度'] != 0.0:
             ROOM_SET_TEMPERATURE = home_data_list[j]['ROOM_SET_TEMPERATURE']
             room_t = home_data_list[j]['室内温度']
             break
            #  return home_data_list[j]['ROOM_SET_TEMPERATURE'], home_data_list[j]['室内温度']
        else:
            unvalid += 1
    
    if unvalid <= 5:
        return ROOM_SET_TEMPERATURE, room_t
    
    other_home_re = None
    for other_home in data_dict.keys():
        if data_dict[other_home]['单元名'] == apart and data_dict[other_home]['layer'] == home_layer and \
            data_dict[other_home]['number'] < home_number: # 同单元，同层，不同户
            other_home_re = other_home
            break

    if other_home_re is None:
        for other_home in list(data_dict.keys())[::-1]:
            if data_dict[other_home]['单元名'] == apart and data_dict[other_home]['layer'] < home_layer and \
                data_dict[other_home]['number'] == home_number:
                other_home_re = other_home
                break

    if other_home_re is None:
        for other_home in list(data_dict.keys())[::-1]:
            if data_dict[other_home]['单元名'] == apart and data_dict[other_home]['layer'] < home_layer:
                other_home_re = other_home
                break

    if other_home_re is None:
        for other_home in list(data_dict.keys())[::-1]:
            if data_dict[other_home]['单元名'] < apart and data_dict[other_home]['layer'] == home_layer and \
                data_dict[other_home]['number'] == home_number:
                other_home_re = other_home
                break
    
    if other_home_re is None:
        for other_home in list(data_dict.keys())[::-1]:
            if data_dict[other_home]['单元名'] < apart and data_dict[other_home]['layer'] == home_layer:
                other_home_re = other_home
                break
    
    if other_home_re is None:
        for other_home in list(data_dict.keys())[::-1]:
            if data_dict[other_home]['单元名'] < apart and data_dict[other_home]['layer'] < home_layer:
                other_home_re = other_home
                break

    assert other_home_re is not None
    other_home_data = data_dict[other_home_re]['data']
    # pdb.set_trace()
    target_time = data['time']
    time_list = []
    for _data in other_home_data:
        time_list.append(_data['time'])
    
    pos = bisect.bisect_left(time_list, target_time)
    # pdb.set_trace()
    if pos == 0:  # 插入点在开头
        closest_time = time_list[0]
        ROOM_SET_TEMPERATURE = other_home_data[pos]['ROOM_SET_TEMPERATURE']
        room_t = other_home_data[pos]['室内温度']
    elif pos == len(time_list):  # 插入点在末尾
        closest_time = time_list[-1]
        ROOM_SET_TEMPERATURE = other_home_data[-1]['ROOM_SET_TEMPERATURE']
        room_t = other_home_data[-1]['室内温度']
    else:  # 比较插入点前后的元素
        before = time_list[pos - 1]
        after = time_list[pos]
        ROOM_SET_TEMPERATURE = (other_home_data[pos - 1]['ROOM_SET_TEMPERATURE'] + other_home_data[pos]['ROOM_SET_TEMPERATURE'])/2
        room_t = (other_home_data[pos-1]['室内温度'] + other_home_data[pos]['室内温度'])/2
        # return (other_home_data[pos - 1]['ROOM_SET_TEMPERATURE'] + other_home_data[pos]['ROOM_SET_TEMPERATURE'])/2,\
        #     (other_home_data[pos-1]['室内温度'] + other_home_data[pos]['室内温度'])/2
    
    # try:
    #     assert math.isnan(ROOM_SET_TEMPERATURE) == False and ROOM_SET_TEMPERATURE != 0.0 and\
    #             math.isnan(room_t) == False and room_t != 0.0
    # except:
    #     pdb.set_trace()
    # if home == "3单元_506":
    #     pdb.set_trace()
    return ROOM_SET_TEMPERATURE, room_t
    # return 0, 0




for home in data_dict.keys():
    for i, data in enumerate(data_dict[home]['data']):
        if math.isnan(data['ROOM_SET_TEMPERATURE']) or data['ROOM_SET_TEMPERATURE'] == 0.0 or\
            math.isnan(data['室内温度']) or data['室内温度'] == 0.0:
            ROOM_SET_TEMPERATURE, room_t = find_t(i, data, home, data_dict)
            assert math.isnan(ROOM_SET_TEMPERATURE) == False and ROOM_SET_TEMPERATURE != 0.0 and\
                math.isnan(room_t) == False and room_t != 0.0
            data['ROOM_SET_TEMPERATURE'] = ROOM_SET_TEMPERATURE
            data['室内温度'] = room_t



# pdb.set_trace()

# from openpyxl import Workbook

# # 创建一个新的工作簿
# wb = Workbook()
# ws = wb.active  # 获取默认工作表

keys = ['building_name',
	'单元名', '单户号码',
    'address_2nd',
    '累计热量',
    '累计流量',	'流速',	'进水温度',	'出水温度',	'室内温度',	'ROOM_SET_TEMPERATURE',	
    'OPEN_STATUS',	'功率',	'RUNNING_STATE', '数据采集时间',	'dtemp'
]
out_dict = {}

for key in keys:
    out_dict[key] = []


for home in data_dict.keys():
    for i, data in enumerate(data_dict[home]['data']):
        for key in keys:
            out_dict[key].append(data[key])

df = pd.DataFrame(out_dict)

# 写入 Excel 文件
df.to_excel("out.xlsx", index=False)



