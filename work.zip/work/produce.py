import pandas as pd
import math
from datetime import datetime, timedelta
import bisect
import torch
import torch.nn as nn
import numpy as np
import pdb
# 读取 Excel 文件
df = pd.read_excel('/local/code/work/out.xlsx', sheet_name='Sheet1')  # 指定工作表名称
df2 = pd.read_excel('/local/code/work/excel2.xlsx', sheet_name='Sheet1')  # 指定工作表名称


input_size = 4
output_size = 1
hidden_size = 128
# 定义 MLP 模型
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(4, hidden_size)   # 输入层到隐藏层
        self.fc2 = nn.Linear(hidden_size, hidden_size)  # 隐藏层到隐藏层
        self.fc3 = nn.Linear(hidden_size, 1)    # 最后一层输出层

    def forward(self, x):
        x = torch.relu(self.fc1(x))           # 激活函数 ReLU
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# 遍历每行数据
data_dict = {}
for index, row in df.iterrows():
    row_data_dict = row.to_dict()
    home = row_data_dict['单元名'] + '_' + str(row_data_dict['单户号码'])
    if data_dict.get(home) is None:
        data_dict[home] = dict()
        data_dict[home]['data'] = []
        data_dict[home]['collcet_time'] = []
    collect_time = row_data_dict['数据采集时间']
    format_time = datetime.strptime(collect_time, '%Y-%m-%d %H:%M:%S.%f')
    format_time_str = format_time.strftime("%Y/%m/%d %H:%M")
    format_time = datetime.strptime(format_time_str, "%Y/%m/%d %H:%M")
    data_dict[home]['data'].append(row_data_dict)
    data_dict[home]['collcet_time'].append(format_time)

outdoor_t_list = []
outdoor_time_list = []
for index, row in df2.iterrows():
    # print(f"第 {index} 行数据: {row.to_dict()}")
    row_data_dict = row.to_dict()
    # pdb.set_trace() 
    format_collect_time = row_data_dict['时间'].to_pydatetime()
    # datetime.strptime(row_data_dict['时间'], '%Y/%m/%d %H:%M')
    outdoor_time_list.append(format_collect_time)
    outdoor_t_list.append(row_data_dict['温度'])

def get_intepolate_value(data_list, time_list, target_time, pos, key):
    if pos == 0:  # 插入点在开头
        value = data_list[0][key]

    elif pos == len(time_list):  # 插入点在末尾
        value = data_list[-1][key]

    else:  # 比较插入点前后的元素
        before = time_list[pos - 1]
        after = time_list[pos]
        time_diff= target_time - before
        time_diff2 = after - target_time
        time_diff3 = after - before
        # 将差值转换为分钟
        diff_in_minutes = time_diff.total_seconds() / 60
        diff2_in_minutes = time_diff2.total_seconds() / 60
        diff3_in_minutes = time_diff3.total_seconds() / 60
        value = (diff2_in_minutes / diff3_in_minutes) * data_list[pos - 1][key] + \
            (diff_in_minutes / diff3_in_minutes) * data_list[pos][key]
    return value

def get_flow_in_out_t(target_time, data_list, time_list):
    pos = bisect.bisect_left(time_list, target_time)
    flow = get_intepolate_value(data_list, time_list, target_time, pos, "流速")
    in_t = get_intepolate_value(data_list, time_list, target_time, pos, "进水温度") 
    out_t = get_intepolate_value(data_list, time_list, target_time, pos, "出水温度") 

    return flow, in_t, out_t

def get_outdoor_t(target_time, outdoor_time_list, outdoor_t_list):
    pos = bisect.bisect_left(outdoor_time_list, target_time)
    if pos == 0:  # 插入点在开头
        value = outdoor_t_list[0]

    elif pos == len(outdoor_time_list):  # 插入点在末尾
        value = outdoor_t_list[-1]

    else:  # 比较插入点前后的元素
        before = outdoor_time_list[pos - 1]
        after = outdoor_time_list[pos]
        time_diff= target_time - before
        time_diff2 = after - target_time
        time_diff3 = after - before
        # 将差值转换为分钟
        diff_in_minutes = time_diff.total_seconds() / 60
        diff2_in_minutes = time_diff2.total_seconds() / 60
        diff3_in_minutes = time_diff3.total_seconds() / 60
        value = (diff2_in_minutes / diff3_in_minutes) * outdoor_t_list[pos - 1] + \
            (diff_in_minutes / diff3_in_minutes) * outdoor_t_list[pos]
    return value


def normalize(x):
    inputs_min_vals = np.array([  0.      ,   6.6     ,   0.      , -15.976152], dtype=np.float32)
    inputs_max_vals = np.array([ 2.4 , 55.11, 50.6 , 18.3 ], dtype=np.float32)
    normalized_x = (x - inputs_min_vals) / (inputs_max_vals - inputs_min_vals)
    return normalized_x

def reverse_normalize(norm_x):
    ouputs_min_vals = 9.8
    ouputs_max_vals = 26.8
    x = norm_x * (ouputs_max_vals - ouputs_min_vals) + ouputs_min_vals
    return x

out_dict = {}
out_dict['building_name'] = []
out_dict['单元名'] = []
out_dict['单户号码'] = []
out_dict['流速'] = []
out_dict['进水温度'] = []
out_dict['出水温度'] = [] 
out_dict['室内温度'] = []
out_dict['数据采集时间'] = []
model = MLP()
state_dict_path = "/local/code/work/mlp_model_acc0.05654194578528404.pth" 
state_dict = torch.load(state_dict_path)
model.load_state_dict(state_dict)
for home in data_dict.keys():
    begin_time = data_dict[home]['collcet_time'][-1] 
    end_time = begin_time + timedelta(days=1)
    tmp_time = begin_time
    while tmp_time <= end_time:
        target_time = tmp_time - timedelta(days=1)
        flow, in_t, out_t = get_flow_in_out_t(target_time, data_dict[home]['data'], data_dict[home]['collcet_time'])
        outdoor_t = get_outdoor_t(tmp_time, outdoor_time_list, outdoor_t_list)
        inputs_np = np.array([flow, in_t, out_t, outdoor_t])
        inputs_np_norm = normalize(inputs_np)
        inputs_torch = torch.from_numpy(inputs_np_norm).float()
        inputs_torch = inputs_torch.reshape(1, -1)
        output = model(inputs_torch)
        output_np = output.detach().numpy()
        output_un_norm = reverse_normalize(output_np.flatten())
        in_door_t = float(output_un_norm)
        out_dict['building_name'].append(data_dict[home]['data'][0]["building_name"])
        out_dict['单元名'].append(data_dict[home]['data'][0]["单元名"])
        out_dict['单户号码'].append(data_dict[home]['data'][0]["单户号码"])
        out_dict['流速'].append(flow)
        out_dict['进水温度'].append(in_t)
        out_dict['出水温度'].append(out_t)
        out_dict['室内温度'].append(in_door_t)

        formatted_time = tmp_time.strftime("%Y-%m-%d %H:%M:%S") + ".000"
        out_dict['数据采集时间'].append(formatted_time)

        tmp_time = tmp_time + timedelta(minutes=25)

df = pd.DataFrame(out_dict)

# 写入 Excel 文件
df.to_excel("out3.xlsx", index=False)  

        
        
    



